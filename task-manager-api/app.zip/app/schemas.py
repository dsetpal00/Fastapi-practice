from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Annotated, Optional

class CreateUser(BaseModel):
    email: EmailStr
    password: str

class Task(BaseModel):
    title: str
    description: str
    due_date: datetime

class taskAlloted(BaseModel):
    status: str
    title: str
    due_date: datetime

class TokenData(BaseModel):
    id: Optional[str] = None

class Token(BaseModel):
    sub: str

class UserResponse(BaseModel):
    user_id: str
    email: EmailStr

class TaskResponse(Task):
    status: str

class TaskUpdate(Task):
    status: str = "Pending"