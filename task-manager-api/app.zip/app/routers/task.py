from fastapi import FastAPI, APIRouter, Depends, status, HTTPException, Response
from sqlalchemy.orm import Session
from .. import db, schemas, models, oauth2

router = APIRouter(
    prefix="/tasks",
    tags = ["Tasks"]
)

@router.post("/", status_code = status.HTTP_201_CREATED, response_model = schemas.taskAlloted)
def create_task(task: schemas.Task, db: Session = Depends(db.get_db), current_user: models.User = Depends(oauth2.get_current_user)):

    new_task = models.Task(user_id = current_user.user_id, **task.model_dump())
    response_text = schemas.taskAlloted
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    return new_task


@router.get("/{id}", status_code = status.HTTP_200_OK, response_model = schemas.TaskResponse)
def get_tasks(id: int, db: Session = Depends(db.get_db), current_user: models.User = Depends(oauth2.get_current_user)):
    task = db.query(models.Task).filter(models.Task.task_id == id, models.Task.user_id == current_user.user_id).first()
    
    print(task)

    if not task:
        raise HTTPException(status_code = status.HTTP_404_NOT_FOUND, detail=f"Post with id : {id} was not found.")
    
    return task

@router.delete("/{id}", status_code = status.HTTP_204_NO_CONTENT)
def delete_task(id: int, db: Session= Depends(db.get_db), current_user: models.User = Depends(oauth2.get_current_user)):
    deleted_task = db.query(models.Task).filter(models.Task.task_id == id, models.Task.user_id == current_user.user_id).first()

    if deleted_task is None:
        raise HTTPException(status_code= status.HTTP_403_FORBIDDEN, detail = "Not authorized to perform requested action.")

    db.delete(deleted_task)
    db.commit()

    return Response(status_code=status.HTTP_204_NO_CONTENT)

@router.put("/{id}", status_code = status.HTTP_200_OK, response_model = schemas.Task)
def update_task(id: int, task: schemas.Task, db: Session = Depends(db.get_db), current_user: models.User = Depends(oauth2.get_current_user)):
    task_query = db.query(models.Task).filter(models.Task.user_id == current_user.user_id , models.Task.task_id == id)
    update_task = task_query.first()

    if update_task is None:
        raise HTTPException(
            status_code = status.HTTP_404_NOT_FOUND,
            detail = f"Task with id: {id} was not found"
        )

    task_query.update(task.model_dump(), synchronize_session = False)
    db.commit()
    db.refresh(update_task)

    return update_task

# get all tasks of user
@router.get("/", status_code = status.HTTP_200_OK)
def get_my_tasks(db: Session = Depends(db.get_db), current_user: models.User = Depends(oauth2.get_current_user)):
    task_query = db.query(models.Task).filter(models.Task.user_id == current_user.user_id).all()

    return {"my_tasks": task_query}
    