from fastapi import FastAPI, APIRouter, Depends, status, HTTPException, Response
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from .. import db, models, schemas, oauth2

router = APIRouter(
    prefix = "/users",
    tags = ["Users"]
)

@router.post("/", response_model = schemas.UserResponse)
def create_user(user :schemas.CreateUser, db: Session = Depends(db.get_db)):

    user.password = oauth2.hash_password(user.password)
    new_user = models.User(**user.model_dump())\
    #duplicate email wala case handle krne ke liye check
    try:
        db.add(new_user)
        db.commit()
    except IntegrityError:
        db.roll_back()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail = "Email already registered")
    
    db.refresh(new_user)
    return new_user

@router.get("/", response_model = schemas.UserResponse)
def all_users(db: Session = Depends(db.get_db)):
    return db.query(models.User).all()

@router.delete("/")
def delete_user(id: int, db: Session = Depends(db.get_db), current_user : models.User = Depends(oauth2.get_current_user)):

    db.delete(current_user)
    db.commit()

    return Response(status_code=204)
