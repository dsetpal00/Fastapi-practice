from sqlalchemy import Column, Integer, String ,Boolean ,ForeignKey, DateTime
from datetime import datetime
from sqlalchemy.orm import relationship
from .db import Base

class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True)
    email = Column(String, nullable=False, unique=True)
    password = Column(String, nullable = False)

class Task(Base):
    __tablename__ = "tasks"
    
    task_id = Column(Integer, primary_key = True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    title = Column(String)
    description = Column(String)
    task_date = Column(DateTime, default=datetime.now)
    due_date = Column(DateTime)
    status = Column(String, default = "pending")